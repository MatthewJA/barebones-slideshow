=== Barebones Slideshow ===
Contributors: MatthewJA
Tags: slideshow, simple
License: GPL v2
License URI: http://www.gnu.org/licenses/gpl-2.0.html

A simple, easily CSS customisable slideshow. Intended to be easy to format for your own layout.

=== Description ===
A simple, easily CSS customisable slideshow. The slideshow is displayed simply as a `div` with class `.barebones-slideshow`. The div contains images, and they have class `.barebones-slideshow-image`. There can also be captions on the slides, and they will be in a div with class `.barebones-slideshow-caption`. This simple structure makes it easy to format.

More info may be available [at the repository for the plugin](http://github.com/MatthewJA/barebones-slideshow).